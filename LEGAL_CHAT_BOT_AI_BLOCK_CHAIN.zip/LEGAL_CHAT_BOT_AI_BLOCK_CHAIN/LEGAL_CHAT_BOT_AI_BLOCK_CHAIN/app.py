from flask import jsonify
from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import g4f
import asyncio
import sys
from tkinter import Message
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///court_system.db'
app.secret_key = 'your_secret_key'

db = SQLAlchemy(app)




# Set the event loop policy to WindowsSelectorEventLoopPolicy
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# System prompt for Indian legal laws
SYSTEM_PROMPT = (
    "You are an expert in Indian legal laws. You will only provide information and answers related to Indian legal laws. "
    "If the query is not related to Indian legal laws, respond with 'I'm sorry, I can only provide information about Indian legal laws.'"
)

# Function to generate responses using GPT-4
def generate_response(user_input):
    """Generate a response using GPT-4."""
    try:
        response = g4f.ChatCompletion.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_input}
            ],
            temperature=0.6,
            top_p=0.9
        )
        return response.strip() if response else "Chatbot: Sorry, I didn't understand that."
    except Exception as e:
        return f"Chatbot: Error: {e}"

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input']
    response = generate_response(user_input)
    return jsonify({'response': response})





# User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)


# Lower Court Model
class Lower(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    division = db.Column(db.String(100), nullable=False)
    degree = db.Column(db.String(100), nullable=False)
    notified_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    status = db.Column(db.String(100), default='Pending')
    
    user = db.relationship('User', backref=db.backref('lowers', lazy=True))


# Case Details Model
class CaseDetails(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    case_description = db.Column(db.String(200), nullable=False)
    hearing_date = db.Column(db.DateTime, nullable=False)
    court_location = db.Column(db.String(200), nullable=False)
    lower_id = db.Column(db.Integer, db.ForeignKey('lower.id'))
    notified_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

    lower = db.relationship('Lower', backref=db.backref('case_details', lazy=True))


class CaseMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('lower.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    case_id = db.Column(db.Integer, db.ForeignKey('case_details.id'))  # <-- add this
    message = db.Column(db.Text, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    case = db.relationship('CaseDetails', backref='notifications')


@app.route('/')
def home():
    return render_template('home.html')

@app.route('/adlower')
def adlower():
     lowers = Lower.query.all()
     return render_template('ad_lower.html', lowers=lowers)

# Admin Login
@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username == 'admin' and password == 'admin123':
            session['admin_logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials')
    
    return render_template('admin_login.html')


@app.route('/admin_dashboard')
def admin_dashboard():
    if 'admin_logged_in' not in session:
        return redirect(url_for('admin_login'))
    
    lowers = Lower.query.all()
    return render_template('admin_dashboard.html', lowers=lowers)


@app.route('/add_lower', methods=['GET', 'POST'])
def add_lower():
    if 'admin_logged_in' not in session:
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        division = request.form['division']
        degree = request.form['degree']

        new_lower = Lower(name=name, age=age, division=division, degree=degree, notified_user_id=None)

        db.session.add(new_lower)
        db.session.commit()
        
        flash('Lower added successfully', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('add_lower.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already taken')
        else:
            hashed_password = generate_password_hash(password)
            new_user = User(username=username, password=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Please log in.')
            return redirect(url_for('user_login'))
    
    return render_template('register.html')


@app.route('/user_login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_logged_in'] = True
            session['username'] = user.username
            session['user_id'] = user.id
            return redirect(url_for('user_dashboard'))
        else:
            flash('Invalid credentials')
    
    return render_template('user_login.html')


@app.route('/user_dashboard')
def user_dashboard():
    if 'user_logged_in' not in session:
        return redirect(url_for('user_login'))

    user_id = session.get('user_id')
    user = db.session.get(User, user_id)
    lowers = Lower.query.filter_by(status='Pending').all()
    return render_template('user_dashboard.html', lowers=lowers, user=user)

@app.route('/update_status/<int:lower_id>', methods=['POST'])
def update_status(lower_id):
    lower = Lower.query.get_or_404(lower_id)
    new_status = request.form['status']
    
    # Update status
    lower.status = new_status
    db.session.commit()
    
    flash(f"Status for {lower.name} updated to {new_status}")
    return redirect(url_for('admin_dashboard'))


@app.route('/notify_lower/<int:lower_id>')
def notify_lower(lower_id):
    if 'user_logged_in' not in session:
        return redirect(url_for('user_login'))

    lower = Lower.query.get_or_404(lower_id)
    lower.status = 'Notified'
    db.session.commit()
    flash(f'Notification sent to {lower.name}')
    return redirect(url_for('user_dashboard'))



@app.route('/lower_login', methods=['GET', 'POST'])
def lower_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        lower = Lower.query.filter_by(name=username, age=password).first()  # Check age as password
        
        if lower:
            session['lower_logged_in'] = True
            session['lower_id'] = lower.id  # Store user ID in session
            return redirect(url_for('lower_dashboard', lower_id=lower.id))
        else:
            flash('Unauthorized access. Please log in again.', 'error')
            return redirect(url_for('lower_login'))  # Redirect on failure

    return render_template('lower_login.html')



@app.route('/notifications/<int:user_id>')
def notifications(user_id):
    if 'user_logged_in' not in session or session.get('user_id') != user_id:
        flash("Unauthorized access. Please log in again.", "danger")
        return redirect(url_for('user_login'))

    user = User.query.get_or_404(user_id)
    notifications = Notification.query.filter_by(user_id=user_id).order_by(Notification.timestamp.desc()).all()

    return render_template('notifications.html', user=user, notifications=notifications)


@app.route('/lower_dashboard/<int:lower_id>', methods=['GET', 'POST'])
def lower_dashboard(lower_id):
    if 'lower_logged_in' not in session or session.get('lower_id') != lower_id:
        flash("Unauthorized access. Please log in again.", "danger")
        return redirect(url_for('lower_login'))

    lower = Lower.query.get_or_404(lower_id)
    users = User.query.all()

    if request.method == 'POST':
        case_description = request.form.get('case_description', '').strip()
        hearing_date_str = request.form.get('hearing_date', '').strip()
        court_location = request.form.get('court_location', '').strip()
        user_id = request.form.get('user_id')
        message_text = request.form.get('message', '').strip()

        if not case_description or not hearing_date_str or not court_location or not user_id:
            flash("All fields are required!", "warning")
            return redirect(url_for('lower_dashboard', lower_id=lower.id))

        try:
            hearing_date = datetime.strptime(hearing_date_str, '%Y-%m-%d')

            case = CaseDetails(
                case_description=case_description,
                hearing_date=hearing_date,
                court_location=court_location,
                lower_id=lower.id
            )
            db.session.add(case)
            db.session.commit()  # Commit to get case.id

            # Send notification with linked case
            if message_text:
                notification = Notification(
                    user_id=user_id,
                    case_id=case.id,  # <-- linking the case
                    message=message_text,
                    timestamp=datetime.utcnow()
                )
                db.session.add(notification)
                db.session.commit()

            flash('Case details submitted successfully and notification sent!', "success")
            return redirect(url_for('lower_dashboard', lower_id=lower.id))

        except ValueError:
            flash("Invalid date format. Use YYYY-MM-DD.", "danger")

    return render_template('lower_dashboard.html', lower=lower, users=users)



# Profile Routes for User and Lower
@app.route('/profile/<int:user_id>')
def profile(user_id):
    if 'user_logged_in' not in session:
        return redirect(url_for('user_login'))

    user = User.query.get_or_404(user_id)
    lowers = Lower.query.filter_by(notified_user_id=user.id).all()
    return render_template('profile.html', user=user, lowers=lowers)

@app.route('/lower_profile/<int:lower_id>')
def lower_profile(lower_id):
    if 'lower_logged_in' not in session:
        return redirect(url_for('lower_login'))

    lower = Lower.query.get_or_404(lower_id)
    case_details = CaseDetails.query.filter_by(lower_id=lower.id).all()
    return render_template('lower_profile.html', lower=lower, case_details=case_details)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)